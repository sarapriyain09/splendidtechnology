module.exports = {
  apps: [
    {
      name: "avatar-backend",
      cwd: "./backend",
      script: "./venv/bin/uvicorn",
      args: "app.main:app --host 0.0.0.0 --port 8000",
      interpreter: "none",
      env: {
        ENV_FILE: "../.env.production"
      },
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      max_memory_restart: "700M",
      out_file: "/srv/velynxia/avatarstudio/logs/backend/pm2-out.log",
      error_file: "/srv/velynxia/avatarstudio/logs/backend/pm2-error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss"
    },
    {
      name: "avatar-frontend",
      cwd: "./frontend",
      script: "npm",
      args: "start",
      env: {
        NODE_ENV: "production",
        PORT: "3000"
      },
      instances: 1,
      exec_mode: "fork",
      autorestart: true,
      max_memory_restart: "700M",
      out_file: "/srv/velynxia/avatarstudio/logs/frontend/pm2-out.log",
      error_file: "/srv/velynxia/avatarstudio/logs/frontend/pm2-error.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss"
    }
  ]
};
