from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Velynxia Avatar Studio API"
    database_url: str = "postgresql+psycopg://avatar_user:avatar_pass@localhost:5432/avatar_studio"
    redis_url: str = "redis://localhost:6379/0"
    app_host: str = "0.0.0.0"
    app_port: int = 8000

    app_base_url: str = "http://localhost:8000"
    frontend_url: str = "http://localhost:3000"
    jwt_secret: str = "change-me-in-production"

    heygen_api_key: str = ""
    openai_api_key: str = ""

    minio_root_user: str = ""
    minio_root_password: str = ""
    minio_endpoint: str = "localhost:9000"
    minio_bucket: str = "avatar-media"
    minio_secure: bool = False
    storage_backend: str = "filesystem"
    storage_root: str = "/srv/velynxia/avatarstudio/storage"
    local_media_root: str = "/srv/velynxia/avatarstudio/storage"
    logs_root: str = "/srv/velynxia/avatarstudio/logs"
    backup_root: str = "/srv/velynxia/avatarstudio/storage/backups"

    upload_session_ttl_seconds: int = 3600


settings = Settings()
